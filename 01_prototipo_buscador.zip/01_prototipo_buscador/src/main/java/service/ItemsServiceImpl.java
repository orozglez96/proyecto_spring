package service;

import java.util.List;

import org.springframework.stereotype.Service;

import model.Item;
@Service
public class ItemsServiceImpl implements ItemsService {

	@Override
	public List<Item> buscarPorTematica(String tematica) {
		// TODO Auto-generated method stub
		return null;
	}

}
